# CostGuard

**The intelligent financial firewall for AI and SaaS APIs.**

AI loops can bankrupt your startup overnight.

CostGuard is an outbound API proxy that sits between your application and expensive third-party APIs like OpenAI, Anthropic, and Gemini. It gives engineering teams a local control plane for tenant budgets, request velocity, response caching, spike protection, and usage telemetry before requests ever leave your infrastructure.

## Why

Usage-based AI billing is powerful until a bad loop, retry storm, or runaway agent starts making thousands of calls in minutes. Vendor dashboards usually tell you what was spent after the fact. CostGuard blocks the blast locally, attributes traffic by tenant, and keeps your credit card out of the danger zone.

## Features

- **Security lockdown**: only forwards traffic to explicitly allowed upstream hosts.
- **Tenant-aware quotas**: every proxied request carries `X-CostGuard-Tenant-ID`.
- **Token Bucket rate limiting**: Redis-backed request velocity control with configurable refill rate and burst size.
- **Spike Circuit Breaker**: detects exponential per-minute traffic jumps and blocks the tenant locally for 15 minutes by default.
- **Response Caching**: Redis-backed cache for duplicate `GET`/`HEAD` requests and opt-in `POST` requests.
- **Fail-Open design**: Redis or telemetry failures are logged, but core app traffic keeps flowing.
- **Vendor usage parsing**: extracts OpenAI chat completion token usage from successful JSON responses.
- **Docker-first deployment**: runs cleanly with Docker Compose and Redis.

## Quickstart

Start CostGuard and Redis:

```bash
docker compose up --build
```

The proxy listens at:

```text
http://localhost:8080
```

Health check:

```bash
curl http://localhost:8080/health
```

Expected:

```json
{"status":"ok"}
```

Proxy a request to an allowed upstream:

```bash
curl -i http://localhost:8080/v1/models \
  -H "X-CostGuard-Tenant-ID: demo-tenant" \
  -H "X-CostGuard-Target-URL: https://api.openai.com/v1/models" \
  -H "Authorization: Bearer YOUR_OPENAI_API_KEY"
```

Test the security lockdown:

```bash
curl -i http://localhost:8080/ \
  -H "X-CostGuard-Tenant-ID: demo-tenant" \
  -H "X-CostGuard-Target-URL: https://example.com/"
```

Expected:

```http
HTTP/1.1 403 Forbidden
```

```json
{"error":"target host is not allowed"}
```

## How It Works

```text
Internal App
    |
    |  X-CostGuard-Tenant-ID
    |  X-CostGuard-Target-URL
    v
CostGuard Proxy
    |
    |-- Security allowlist
    |-- Spike Circuit Breaker
    |-- Token Bucket rate limiting
    |-- Response cache lookup
    |-- Budget consumption
    |-- Usage metrics
    v
Paid API Provider
```

## Architecture

### Fail-Open Design

CostGuard is designed to protect your bill without taking down your product. If Redis or telemetry storage is unavailable, limiter/cache/metrics operations log the error and traffic is allowed through. Your app keeps working while the infrastructure issue is investigated.

### Token Bucket Rate Limiting

Request velocity is enforced with a Redis-backed Token Bucket per tenant.

Redis key:

```text
costguard:tenant:{tenant_id}:requests:bucket
```

Stored as a Redis hash:

```text
tokens
last_refill_ms
```

Configuration:

```text
REQUEST_REFILL_RATE_PER_SECOND=10
REQUEST_BURST_CAPACITY=100
```

This allows short bursts while preventing sustained traffic floods.

### Spike Circuit Breaker

CostGuard monitors per-minute request volume per tenant. If the current minute exceeds both a minimum request threshold and a multiplier over the previous minute, the circuit trips.

Redis keys:

```text
costguard:tenant:{tenant_id}:requests:minute:{epoch_minute}
costguard:tenant:{tenant_id}:circuit:open
```

Configuration:

```text
SPIKE_BREAKER_ENABLED=true
SPIKE_MIN_REQUESTS_PER_MINUTE=100
SPIKE_MULTIPLIER=5
SPIKE_BLOCK_SECONDS=900
```

When tripped, CostGuard logs a critical alert and returns local `429` responses for that tenant until the circuit expires.

### Response Caching

CostGuard caches successful `2xx` responses in Redis.

Default behavior:

| Method | Cached |
|--------|--------|
| `GET` | Yes |
| `HEAD` | Yes |
| `POST` | Only with `X-CostGuard-Cache: ENABLE` |
| Other | No |

Cache key:

```text
costguard:cache:{tenant_id}:{sha256}
```

The hash includes tenant, method, target URL, selected headers, and request body. Tenants never share cache entries.

Example cached request:

```bash
curl -i http://localhost:8080/ \
  -H "X-CostGuard-Tenant-ID: demo-tenant" \
  -H "X-CostGuard-Target-URL: https://api.openai.com/v1/models" \
  -H "X-CostGuard-TTL: 300" \
  -H "Authorization: Bearer YOUR_OPENAI_API_KEY"
```

Look for:

```text
X-CostGuard-Cache: MISS
```

Repeat the same request and look for:

```text
X-CostGuard-Cache: HIT
```

## Required Headers

| Header | Required | Description |
|--------|----------|-------------|
| `X-CostGuard-Tenant-ID` | Yes | Tenant/account/feature identifier used for limits and attribution |
| `X-CostGuard-Target-URL` | Yes | Absolute upstream URL to call |
| `X-CostGuard-Cache` | No | `ENABLE` for POST caching, `BYPASS` to skip cache |
| `X-CostGuard-TTL` | No | Cache TTL in seconds, from `1` to `86400` |

Health endpoints do not require CostGuard headers:

```text
/health
/_costguard/health
```

## Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `LISTEN_ADDR` | `:8080` | Proxy bind address |
| `ALLOWED_TARGET_HOSTS` | `api.openai.com,api.anthropic.com,api.google.com` | Exact upstream hosts CostGuard may call |
| `REDIS_ADDR` | `localhost:6379` | Redis address |
| `REDIS_PASSWORD` | empty | Optional Redis password |
| `REQUEST_REFILL_RATE_PER_SECOND` | `10` | Token Bucket refill rate per tenant |
| `REQUEST_BURST_CAPACITY` | `100` | Token Bucket burst capacity per tenant |
| `SPIKE_BREAKER_ENABLED` | `true` | Enable per-tenant spike circuit breaker |
| `SPIKE_MIN_REQUESTS_PER_MINUTE` | `100` | Minimum minute volume before spike detection can trip |
| `SPIKE_MULTIPLIER` | `5` | Current minute must be this many times previous minute |
| `SPIKE_BLOCK_SECONDS` | `900` | Circuit breaker block duration |
| `DEFAULT_HOURLY_BUDGET` | `10000` | Tenant budget units per hour |
| `DEFAULT_REQUEST_COST` | `1` | Budget units charged per upstream request |
| `CACHE_DEFAULT_TTL_SECONDS` | `300` | Default response cache TTL |
| `METRICS_ENABLED` | `true` | Enable async request metrics |
| `METRICS_DB_PATH` | empty | Optional SQLite metrics path |

## Error Responses

CostGuard-generated errors are JSON.

```json
{"error":"missing required header: X-CostGuard-Tenant-ID"}
```

```json
{"error":"target host is not allowed"}
```

Rate-limit and circuit-breaker responses:

```json
{
  "error": "rate_limit_exceeded",
  "tenant_id": "demo-tenant",
  "reason": "circuit_open",
  "retry_after_seconds": 900
}
```

Common statuses:

| Status | Meaning |
|--------|---------|
| `400` | Missing or invalid CostGuard header |
| `403` | Target host is not allowed |
| `429` | Token bucket, circuit breaker, or budget limit blocked the request |
| `502` | Upstream request failed |

## Development

Run locally:

```bash
go run ./cmd/proxy
```

Run tests:

```bash
go test ./...
```

Build:

```bash
go build ./...
```

Project layout:

```text
cmd/proxy/main.go       # service entrypoint
internal/proxy/         # HTTP proxy pipeline
internal/limiter/       # Redis token bucket, spike breaker, budget guardrails
internal/cache/         # Redis response cache
internal/metrics/       # async JSON/SQLite metrics and vendor usage parsing
internal/redis/         # Redis client setup
internal/config/        # environment config
```

## Status

CostGuard is an early backend-focused prototype for teams building AI-heavy SaaS products. It already covers the critical path: secure outbound routing, tenant-aware guardrails, Token Bucket rate limiting, spike circuit breaking, Response Caching, Fail-Open behavior, and basic usage telemetry.
