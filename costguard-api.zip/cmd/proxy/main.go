package main

import (
	"context"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"costguard/internal/cache"
	"costguard/internal/config"
	"costguard/internal/limiter"
	"costguard/internal/metrics"
	"costguard/internal/proxy"
	redisx "costguard/internal/redis"
)

func main() {
	cfg := config.Load()

	client := redisx.NewClientFromEnv()
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	if err := redisx.Ping(ctx, client); err != nil {
		log.Printf("redis: ping failed (limiter/cache fail-open): %v", err)
	} else {
		log.Printf("redis: connected at %s", cfg.RedisAddr)
	}
	cancel()

	lim := limiter.NewFromEnv(client)
	cacheSvc := cache.NewService(client)
	rec := metrics.NewRecorder(cfg.MetricsEnabled, cfg.MetricsWorkers, cfg.MetricsBuffer, cfg.MetricsDBPath)
	defer rec.Close()

	handler := proxy.NewHandler(lim, cacheSvc, rec, cfg.MetricsDefaultCost, cfg.MetricsEnabled, cfg.AllowedTargetHosts)

	mux := http.NewServeMux()
	mux.Handle("/", handler)

	srv := &http.Server{
		Addr:    cfg.ListenAddr,
		Handler: mux,
	}

	go func() {
		log.Printf("CostGuard proxy listening on %s (metrics=%v)", cfg.ListenAddr, cfg.MetricsEnabled)
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatal(err)
		}
	}()

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
	<-stop

	shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer shutdownCancel()
	_ = srv.Shutdown(shutdownCtx)
}
