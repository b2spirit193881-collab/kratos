package cache

import (
	"context"
	"encoding/json"
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"

	goredis "github.com/redis/go-redis/v9"
)

// failOpenLog writes deliberate fail-open messages to stderr (telemetry must not block traffic).
var failOpenLog = log.New(os.Stderr, "", log.LstdFlags)

const (
	HeaderCacheControl = "X-CostGuard-Cache"
	HeaderTTL          = "X-CostGuard-TTL"
	HeaderTenantID     = "X-CostGuard-Tenant-ID"
	HeaderTargetURL    = "X-CostGuard-Target-URL"

	StatusHit    = "HIT"
	StatusMiss   = "MISS"
	StatusBypass = "BYPASS"

	// Request opt-in for caching POST bodies (LLM prompts, enrichment).
	CacheEnable = "ENABLE"

	minTTLSeconds = 1
	maxTTLSeconds = 86400
)

// Entry is a stored upstream response.
type Entry struct {
	StatusCode int                 `json:"status_code"`
	Headers    map[string][]string `json:"headers"`
	Body       []byte              `json:"body"`
}

// Store reads and writes cached responses.
type Store interface {
	Get(ctx context.Context, redisKey string) (*Entry, error)
	Set(ctx context.Context, redisKey string, entry *Entry, ttl time.Duration) error
}

// Service coordinates cache policy, keys, and Redis persistence.
type Service struct {
	store      Store
	defaultTTL time.Duration
}

// NewService wires Redis-backed storage when client is non-nil.
func NewService(client *goredis.Client) *Service {
	var store Store
	if client != nil {
		store = &RedisStore{client: client}
	}
	return &Service{
		store:      store,
		defaultTTL: time.Duration(envInt("CACHE_DEFAULT_TTL_SECONDS", 300)) * time.Second,
	}
}

// Enabled reports whether Redis caching is available.
func (s *Service) Enabled() bool {
	return s != nil && s.store != nil
}

// Mode describes how this request interacts with the cache layer.
type Mode int

const (
	ModeOff Mode = iota
	ModeBypass
	ModeActive
)

// ResolveMode decides whether to read/write the cache for this request.
func ResolveMode(method string, cacheHeader string) Mode {
	if strings.EqualFold(strings.TrimSpace(cacheHeader), StatusBypass) {
		return ModeBypass
	}
	if eligibleMethod(method, cacheHeader) {
		return ModeActive
	}
	return ModeOff
}

func eligibleMethod(method, cacheHeader string) bool {
	switch strings.ToUpper(method) {
	case http.MethodGet, http.MethodHead:
		return true
	case http.MethodPost:
		return strings.EqualFold(strings.TrimSpace(cacheHeader), CacheEnable)
	default:
		return false
	}
}

// ParseTTL reads X-CostGuard-TTL (seconds) or returns the service default.
func (s *Service) ParseTTL(header string) (time.Duration, error) {
	raw := strings.TrimSpace(header)
	if raw == "" {
		return s.defaultTTL, nil
	}
	sec, err := strconv.Atoi(raw)
	if err != nil || sec < minTTLSeconds || sec > maxTTLSeconds {
		return 0, err
	}
	return time.Duration(sec) * time.Second, nil
}

// RedisKey builds costguard:cache:{tenant}:{hash}.
func RedisKey(tenantID, fingerprint string) string {
	return "costguard:cache:" + tenantID + ":" + fingerprint
}

// Get returns a cached entry; Redis errors fail-open (nil, nil).
func (s *Service) Get(ctx context.Context, key string) (*Entry, error) {
	if !s.Enabled() {
		return nil, nil
	}
	entry, err := s.store.Get(ctx, key)
	if err != nil {
		failOpenLog.Printf("cache: get failed (fail-open): %v", err)
		// Fail-Open design choice to prevent downstream application outages during telemetry bottlenecks.
		return nil, nil
	}
	return entry, nil
}

// Set stores an entry; Redis errors fail-open (logged only).
func (s *Service) Set(ctx context.Context, key string, entry *Entry, ttl time.Duration) {
	if !s.Enabled() || entry == nil {
		return
	}
	if err := s.store.Set(ctx, key, entry, ttl); err != nil {
		failOpenLog.Printf("cache: set failed (fail-open): %v", err)
	}
}

// ShouldStore returns true for successful cacheable upstream responses (2xx only).
func ShouldStore(statusCode int) bool {
	return statusCode >= 200 && statusCode < 300
}

// WriteHit writes a cached response to the client.
func WriteHit(w http.ResponseWriter, entry *Entry) {
	for name, values := range entry.Headers {
		for _, v := range values {
			w.Header().Add(name, v)
		}
	}
	w.Header().Set(HeaderCacheControl, StatusHit)
	w.WriteHeader(entry.StatusCode)
	if len(entry.Body) > 0 {
		_, _ = w.Write(entry.Body)
	}
}

// RedisStore persists JSON-encoded Entry values in Redis.
type RedisStore struct {
	client *goredis.Client
}

func (r *RedisStore) Get(ctx context.Context, key string) (*Entry, error) {
	data, err := r.client.Get(ctx, key).Bytes()
	if err == goredis.Nil {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	var entry Entry
	if err := json.Unmarshal(data, &entry); err != nil {
		return nil, err
	}
	return &entry, nil
}

func (r *RedisStore) Set(ctx context.Context, key string, entry *Entry, ttl time.Duration) error {
	data, err := json.Marshal(entry)
	if err != nil {
		return err
	}
	return r.client.Set(ctx, key, data, ttl).Err()
}

func envInt(name string, def int) int {
	v := os.Getenv(name)
	if v == "" {
		return def
	}
	n, err := strconv.Atoi(v)
	if err != nil || n < 0 {
		return def
	}
	return n
}
