package cache

import (
	"crypto/sha256"
	"encoding/hex"
	"net/http"
	"sort"
	"strings"
)

// headers included in POST cache fingerprint (normalized lower-case names).
var keyHeaderNames = []string{
	"accept",
	"authorization",
	"content-type",
}

// Fingerprint returns a SHA-256 hex digest of the canonical request identity.
// Includes tenant, target URL, method, optional normalized headers, and body bytes.
func Fingerprint(tenantID, targetURL, method string, hdr http.Header, body []byte) string {
	h := sha256.New()
	_, _ = h.Write([]byte(tenantID))
	_, _ = h.Write([]byte{0})
	_, _ = h.Write([]byte(strings.ToUpper(method)))
	_, _ = h.Write([]byte{0})
	_, _ = h.Write([]byte(targetURL))
	_, _ = h.Write([]byte{0})
	writeNormalizedHeaders(h, hdr)
	_, _ = h.Write([]byte{0})
	_, _ = h.Write(body)
	return hex.EncodeToString(h.Sum(nil))
}

func writeNormalizedHeaders(h interface {
	Write([]byte) (int, error)
}, hdr http.Header) {
	if hdr == nil {
		return
	}
	for _, name := range keyHeaderNames {
		vals := hdr.Values(name)
		if len(vals) == 0 {
			continue
		}
		sorted := append([]string(nil), vals...)
		sort.Strings(sorted)
		_, _ = h.Write([]byte(name))
		_, _ = h.Write([]byte(":"))
		_, _ = h.Write([]byte(strings.Join(sorted, ",")))
		_, _ = h.Write([]byte{';'})
	}
}

// HeadersForStorage copies upstream response headers safe to replay from cache.
func HeadersForStorage(src http.Header) map[string][]string {
	out := make(map[string][]string)
	for name, values := range src {
		key := strings.ToLower(name)
		if hopByHop(key) {
			continue
		}
		out[name] = append([]string(nil), values...)
	}
	return out
}

func hopByHop(key string) bool {
	switch key {
	case "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
		"te", "trailers", "transfer-encoding", "upgrade":
		return true
	default:
		return false
	}
}
