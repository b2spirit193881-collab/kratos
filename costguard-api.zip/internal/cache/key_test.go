package cache

import (
	"net/http"
	"testing"
)

func TestFingerprintStable(t *testing.T) {
	h := make(http.Header)
	h.Set("Content-Type", "application/json")
	h.Set("Authorization", "Bearer x")

	a := Fingerprint("tenant-a", "https://api.example.com/v1", "POST", h, []byte(`{"q":1}`))
	b := Fingerprint("tenant-a", "https://api.example.com/v1", "POST", h, []byte(`{"q":1}`))
	if a != b {
		t.Fatalf("expected stable fingerprint, got %q vs %q", a, b)
	}

	c := Fingerprint("tenant-b", "https://api.example.com/v1", "POST", h, []byte(`{"q":1}`))
	if a == c {
		t.Fatal("expected different tenant to change fingerprint")
	}
}

func TestResolveMode(t *testing.T) {
	if ResolveMode("GET", "") != ModeActive {
		t.Fatal("GET should be cache-active")
	}
	if ResolveMode("POST", "") != ModeOff {
		t.Fatal("POST without ENABLE should be off")
	}
	if ResolveMode("POST", "ENABLE") != ModeActive {
		t.Fatal("POST with ENABLE should be active")
	}
	if ResolveMode("GET", "BYPASS") != ModeBypass {
		t.Fatal("BYPASS should bypass cache")
	}
}
