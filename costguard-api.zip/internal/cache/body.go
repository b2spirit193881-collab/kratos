package cache

import (
	"bytes"
	"io"
	"net/http"
)

// ReadBodyIfNeeded buffers the request body only when caching is active.
//
// Tradeoff: when ModeActive, the full body is held in memory once so it can
// feed both the SHA-256 fingerprint and a replayable upstream io.Reader.
// Non-cacheable requests keep r.Body untouched for streaming.
// Large LLM payloads should set reasonable client max body limits.
func ReadBodyIfNeeded(r *http.Request, mode Mode) ([]byte, io.ReadCloser, error) {
	if mode != ModeActive {
		return nil, r.Body, nil
	}
	if r.Body == nil {
		return nil, http.NoBody, nil
	}
	body, err := io.ReadAll(r.Body)
	_ = r.Body.Close()
	if err != nil {
		return nil, nil, err
	}
	return body, io.NopCloser(bytes.NewReader(body)), nil
}
