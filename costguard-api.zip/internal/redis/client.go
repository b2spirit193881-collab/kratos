package redis

import (
	"context"
	"fmt"
	"os"
	"strconv"
	"time"

	goredis "github.com/redis/go-redis/v9"
)

// NewClientFromEnv builds a Redis client from REDIS_ADDR and optional REDIS_PASSWORD.
// Empty/unset REDIS_ADDR → localhost:6379 for local dev; when set (e.g. Docker Compose redis:6379), uses env exactly.
func NewClientFromEnv() *goredis.Client {
	addr := os.Getenv("REDIS_ADDR")
	if addr == "" {
		addr = "localhost:6379" // local default; compose wires REDIS_ADDR to the redis service
	}

	opts := &goredis.Options{
		Addr:         addr,
		Password:     os.Getenv("REDIS_PASSWORD"),
		DialTimeout:  2 * time.Second,
		ReadTimeout:  2 * time.Second,
		WriteTimeout: 2 * time.Second,
	}
	if n, err := strconv.Atoi(os.Getenv("REDIS_DB")); err == nil && n >= 0 {
		opts.DB = n
	}
	return goredis.NewClient(opts)
}

// Ping verifies connectivity; used at startup for logging only.
func Ping(ctx context.Context, c *goredis.Client) error {
	if c == nil {
		return fmt.Errorf("redis client is nil")
	}
	return c.Ping(ctx).Err()
}
