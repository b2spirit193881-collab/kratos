package limiter

import "testing"

func TestParseScriptResultAllow(t *testing.T) {
	ok, reason, retry, err := parseScriptResult([]interface{}{int64(1), "", int64(0)})
	if err != nil || !ok || reason != "" || retry != 0 {
		t.Fatalf("unexpected: ok=%v reason=%q retry=%d err=%v", ok, reason, retry, err)
	}
}

func TestParseScriptResultBlockRequestLimit(t *testing.T) {
	ok, reason, retry, err := parseScriptResult([]interface{}{int64(0), "request_rate_limit", int64(2)})
	if err != nil || ok || reason != "request_rate_limit" || retry != 2 {
		t.Fatalf("unexpected: ok=%v reason=%q retry=%d err=%v", ok, reason, retry, err)
	}
}

func TestParseScriptResultBlockBudget(t *testing.T) {
	ok, reason, _, err := parseScriptResult([]interface{}{int64(0), "budget_exhausted", int64(3600)})
	if err != nil || ok || reason != "budget_exhausted" {
		t.Fatalf("unexpected: ok=%v reason=%q err=%v", ok, reason, err)
	}
}

func TestParseScriptResultDetailedCircuitTrip(t *testing.T) {
	ok, reason, retry, tripped, err := parseScriptResultDetailed([]interface{}{int64(0), "circuit_open", int64(900), int64(1)})
	if err != nil || ok || reason != "circuit_open" || retry != 900 || !tripped {
		t.Fatalf("unexpected: ok=%v reason=%q retry=%d tripped=%v err=%v", ok, reason, retry, tripped, err)
	}
}

func TestRedisKeyNames(t *testing.T) {
	if got := requestKey("acme"); got != "costguard:tenant:acme:requests:bucket" {
		t.Fatalf("request key: %s", got)
	}
	if got := minuteKey("acme", 123); got != "costguard:tenant:acme:requests:minute:123" {
		t.Fatalf("minute key: %s", got)
	}
	if got := circuitOpenKey("acme"); got != "costguard:tenant:acme:circuit:open" {
		t.Fatalf("circuit key: %s", got)
	}
	if got := budgetKey("acme"); got != "costguard:tenant:acme:budget:hour" {
		t.Fatalf("budget key: %s", got)
	}
}

func TestBucketTTLSeconds(t *testing.T) {
	if got := bucketTTLSeconds(100, 10); got != minBucketTTL {
		t.Fatalf("expected min ttl, got %d", got)
	}
	if got := bucketTTLSeconds(1000, 1); got != 2000 {
		t.Fatalf("expected ttl based on refill time, got %d", got)
	}
	if got := bucketTTLSeconds(0, 10); got != minBucketTTL {
		t.Fatalf("expected min ttl for invalid config, got %d", got)
	}
}
