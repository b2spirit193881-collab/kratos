package limiter

import (
	"context"
	"fmt"
	"log"
	"math"
	"os"
	"strconv"
	"time"

	goredis "github.com/redis/go-redis/v9"
)

// failOpenLog writes deliberate fail-open messages to stderr (telemetry must not block traffic).
var failOpenLog = log.New(os.Stderr, "", log.LstdFlags)

const hourTTL = 3600
const minBucketTTL = 60
const minuteCounterTTL = 180

// Result describes whether a tenant may proceed.
type Result struct {
	Allowed           bool
	Reason            string // request_rate_limit | circuit_open | budget_exhausted
	RetryAfterSeconds int
}

// Limiter enforces per-tenant request velocity, spike circuit breaking, and budget caps using Redis.
//
// Algorithm: per-minute spike detection, token bucket velocity, fixed hourly budget.
// Keys: costguard:tenant:{id}:circuit:open,
// costguard:tenant:{id}:requests:minute:{epoch_minute},
// costguard:tenant:{id}:requests:bucket, and costguard:tenant:{id}:budget:hour
// Lua scripts check limits before incrementing to keep the hot path atomic.
type Limiter struct {
	client                  *goredis.Client
	requestBucketCapacity   float64
	requestRefillPerSec     float64
	spikeBreakerEnabled     bool
	spikeMinRequests        int64
	spikeMultiplier         float64
	spikeBlockSeconds       int64
	hourlyBudgetLimit       int64
	requestCost             int64
}

// circuitScript tracks per-minute tenant request volume and opens a circuit
// when the current minute grows by a configured multiplier over the previous
// minute after a minimum volume threshold. Returns {allowed, reason,
// retry_after_seconds, tripped_now}.
var circuitScript = `
local breaker_key = KEYS[1]
local current_key = KEYS[2]
local previous_key = KEYS[3]
local minute_ttl = tonumber(ARGV[1])
local block_ttl = tonumber(ARGV[2])
local min_requests = tonumber(ARGV[3])
local multiplier = tonumber(ARGV[4])
local enabled = tonumber(ARGV[5])

if enabled == 0 then
  return {1, '', 0, 0}
end

local open = redis.call('GET', breaker_key)
if open then
  local t = redis.call('TTL', breaker_key)
  if t == nil or t < 0 then t = block_ttl end
  return {0, 'circuit_open', t, 0}
end

local current = redis.call('INCR', current_key)
if current == 1 then
  redis.call('EXPIRE', current_key, minute_ttl)
end

local previous = tonumber(redis.call('GET', previous_key) or '0')
local baseline = math.max(previous, 1)

if current >= min_requests and current >= (baseline * multiplier) then
  redis.call('SET', breaker_key, '1', 'EX', block_ttl)
  return {0, 'circuit_open', block_ttl, 1}
end

return {1, '', 0, 0}
`

// requestScript implements an atomic Redis-backed token bucket.
// Returns {allowed, reason, retry_after_seconds}.
var requestScript = `
local key = KEYS[1]
local capacity = tonumber(ARGV[1])
local refill_per_sec = tonumber(ARGV[2])
local requested = tonumber(ARGV[3])
local ttl = tonumber(ARGV[4])

if capacity <= 0 or refill_per_sec <= 0 then
  return {0, 'request_rate_limit', ttl}
end

local now = redis.call('TIME')
local now_ms = (tonumber(now[1]) * 1000) + math.floor(tonumber(now[2]) / 1000)
local bucket = redis.call('HMGET', key, 'tokens', 'last_refill_ms')
local tokens = tonumber(bucket[1])
local last_refill_ms = tonumber(bucket[2])

if tokens == nil then
  tokens = capacity
end
if last_refill_ms == nil then
  last_refill_ms = now_ms
end

local elapsed_ms = math.max(0, now_ms - last_refill_ms)
tokens = math.min(capacity, tokens + ((elapsed_ms / 1000) * refill_per_sec))

if tokens < requested then
  local missing = requested - tokens
  local retry_after = math.ceil(missing / refill_per_sec)
  redis.call('HSET', key, 'tokens', tokens, 'last_refill_ms', now_ms)
  redis.call('EXPIRE', key, ttl)
  return {0, 'request_rate_limit', retry_after}
end

tokens = tokens - requested
redis.call('HSET', key, 'tokens', tokens, 'last_refill_ms', now_ms)
redis.call('EXPIRE', key, ttl)
return {1, '', 0}
`

// budgetScript checks budget consumption, then INCRBY cost when under limit.
var budgetScript = `
local key = KEYS[1]
local limit = tonumber(ARGV[1])
local cost = tonumber(ARGV[2])
local ttl = tonumber(ARGV[3])
local current = tonumber(redis.call('GET', key) or '0')
if current + cost > limit then
  local t = redis.call('TTL', key)
  if t == nil or t < 0 then t = ttl end
  return {0, 'budget_exhausted', t}
end
redis.call('INCRBY', key, cost)
if redis.call('TTL', key) < 0 then
  redis.call('EXPIRE', key, ttl)
end
return {1, '', 0}
`

// NewFromEnv constructs a limiter using DEFAULT_* environment variables.
func NewFromEnv(client *goredis.Client) *Limiter {
	budget := envInt64("DEFAULT_HOURLY_BUDGET", 0)
	if budget == 0 {
		budget = envInt64("DEFAULT_HOURLY_BUDGET_LIMIT", 10000)
	}
	refill := envFloat64("REQUEST_REFILL_RATE_PER_SECOND", 10)
	capacity := envFloat64("REQUEST_BURST_CAPACITY", 100)
	return &Limiter{
		client:                client,
		requestBucketCapacity: capacity,
		requestRefillPerSec:   refill,
		spikeBreakerEnabled:   envBool("SPIKE_BREAKER_ENABLED", true),
		spikeMinRequests:      envInt64("SPIKE_MIN_REQUESTS_PER_MINUTE", 100),
		spikeMultiplier:       envFloat64("SPIKE_MULTIPLIER", 5),
		spikeBlockSeconds:     envInt64("SPIKE_BLOCK_SECONDS", 900),
		hourlyBudgetLimit:     budget,
		requestCost:           envInt64("DEFAULT_REQUEST_COST", 1),
	}
}

// AllowRequest checks the spike circuit breaker, then consumes one token from
// the tenant request bucket.
// On Redis errors, logs and fail-opens (allows the request).
func (l *Limiter) AllowRequest(ctx context.Context, tenantID string) Result {
	if l == nil || l.client == nil {
		// Fail-Open design choice to prevent downstream application outages during telemetry bottlenecks.
		return Result{Allowed: true}
	}
	if res := l.evalCircuitBreaker(ctx, tenantID); !res.Allowed {
		return res
	}
	return l.evalRequestBucket(ctx, requestKey(tenantID))
}

// ConsumeBudget increments budget units when under limit (skipped on cache hits).
// On Redis errors, logs and fail-opens.
func (l *Limiter) ConsumeBudget(ctx context.Context, tenantID string) Result {
	if l == nil || l.client == nil {
		// Fail-Open design choice to prevent downstream application outages during telemetry bottlenecks.
		return Result{Allowed: true}
	}
	return l.eval(ctx, budgetScript, budgetKey(tenantID), l.hourlyBudgetLimit, l.requestCost)
}

func (l *Limiter) evalCircuitBreaker(ctx context.Context, tenantID string) Result {
	nowMinute := time.Now().Unix() / 60
	raw, err := l.client.Eval(ctx, circuitScript, []string{
		circuitOpenKey(tenantID),
		minuteKey(tenantID, nowMinute),
		minuteKey(tenantID, nowMinute-1),
	},
		minuteCounterTTL,
		l.spikeBlockSeconds,
		l.spikeMinRequests,
		l.spikeMultiplier,
		boolInt(l.spikeBreakerEnabled),
	).Result()
	if err != nil {
		failOpenLog.Printf("limiter: redis circuit breaker eval failed (fail-open): %v", err)
		// Fail-Open design choice to prevent downstream application outages during telemetry bottlenecks.
		return Result{Allowed: true}
	}

	allowed, reason, retryAfter, tripped, err := parseScriptResultDetailed(raw)
	if err != nil {
		failOpenLog.Printf("limiter: unexpected redis circuit breaker response (fail-open): %v", err)
		// Fail-Open design choice to prevent downstream application outages during telemetry bottlenecks.
		return Result{Allowed: true}
	}
	if tripped {
		log.Printf("CRITICAL: spike circuit breaker tripped tenant_id=%s retry_after_seconds=%d min_requests=%d multiplier=%.2f",
			tenantID, retryAfter, l.spikeMinRequests, l.spikeMultiplier)
	}
	if allowed {
		return Result{Allowed: true}
	}
	if retryAfter <= 0 {
		retryAfter = int(l.spikeBlockSeconds)
	}
	return Result{
		Allowed:           false,
		Reason:            reason,
		RetryAfterSeconds: retryAfter,
	}
}

func (l *Limiter) evalRequestBucket(ctx context.Context, key string) Result {
	ttl := bucketTTLSeconds(l.requestBucketCapacity, l.requestRefillPerSec)
	raw, err := l.client.Eval(ctx, requestScript, []string{key},
		l.requestBucketCapacity,
		l.requestRefillPerSec,
		1,
		ttl,
	).Result()
	if err != nil {
		failOpenLog.Printf("limiter: redis token bucket eval failed (fail-open): %v", err)
		// Fail-Open design choice to prevent downstream application outages during telemetry bottlenecks.
		return Result{Allowed: true}
	}

	allowed, reason, retryAfter, err := parseScriptResult(raw)
	if err != nil {
		failOpenLog.Printf("limiter: unexpected redis token bucket response (fail-open): %v", err)
		// Fail-Open design choice to prevent downstream application outages during telemetry bottlenecks.
		return Result{Allowed: true}
	}
	if allowed {
		return Result{Allowed: true}
	}
	if retryAfter <= 0 {
		retryAfter = ttl
	}
	return Result{
		Allowed:           false,
		Reason:            reason,
		RetryAfterSeconds: retryAfter,
	}
}

func (l *Limiter) eval(ctx context.Context, script, key string, limit, cost int64) Result {
	var args []interface{}
	if cost == 0 {
		args = []interface{}{limit, hourTTL}
	} else {
		args = []interface{}{limit, cost, hourTTL}
	}

	raw, err := l.client.Eval(ctx, script, []string{key}, args...).Result()
	if err != nil {
		failOpenLog.Printf("limiter: redis eval failed (fail-open): %v", err)
		// Fail-Open design choice to prevent downstream application outages during telemetry bottlenecks.
		return Result{Allowed: true}
	}

	allowed, reason, retryAfter, err := parseScriptResult(raw)
	if err != nil {
		failOpenLog.Printf("limiter: unexpected redis response (fail-open): %v", err)
		// Fail-Open design choice to prevent downstream application outages during telemetry bottlenecks.
		return Result{Allowed: true}
	}
	if allowed {
		return Result{Allowed: true}
	}
	if retryAfter <= 0 {
		retryAfter = hourTTL
	}
	if ttl, err := l.client.TTL(ctx, key).Result(); err == nil && ttl > 0 {
		retryAfter = int(ttl.Seconds())
	}
	return Result{
		Allowed:           false,
		Reason:            reason,
		RetryAfterSeconds: retryAfter,
	}
}

func parseScriptResult(raw interface{}) (allowed bool, reason string, retryAfter int, err error) {
	allowed, reason, retryAfter, _, err = parseScriptResultDetailed(raw)
	return allowed, reason, retryAfter, err
}

func parseScriptResultDetailed(raw interface{}) (allowed bool, reason string, retryAfter int, tripped bool, err error) {
	vals, ok := raw.([]interface{})
	if !ok || len(vals) < 3 {
		return false, "", 0, false, fmt.Errorf("expected at least 3-element array, got %T", raw)
	}
	flag, err := toInt(vals[0])
	if err != nil {
		return false, "", 0, false, err
	}
	if s, ok := vals[1].(string); ok {
		reason = s
	}
	retryAfter, err = toInt(vals[2])
	if err != nil {
		return false, "", 0, false, err
	}
	if len(vals) >= 4 {
		trippedFlag, err := toInt(vals[3])
		if err != nil {
			return false, "", 0, false, err
		}
		tripped = trippedFlag == 1
	}
	return flag == 1, reason, retryAfter, tripped, nil
}

func toInt(v interface{}) (int, error) {
	switch n := v.(type) {
	case int64:
		return int(n), nil
	case int:
		return n, nil
	case string:
		i, err := strconv.Atoi(n)
		return i, err
	default:
		return 0, fmt.Errorf("cannot convert %T", v)
	}
}

func requestKey(tenantID string) string {
	return fmt.Sprintf("costguard:tenant:%s:requests:bucket", tenantID)
}

func minuteKey(tenantID string, epochMinute int64) string {
	return fmt.Sprintf("costguard:tenant:%s:requests:minute:%d", tenantID, epochMinute)
}

func circuitOpenKey(tenantID string) string {
	return fmt.Sprintf("costguard:tenant:%s:circuit:open", tenantID)
}

func budgetKey(tenantID string) string {
	return fmt.Sprintf("costguard:tenant:%s:budget:hour", tenantID)
}

func envInt64(name string, def int64) int64 {
	v := os.Getenv(name)
	if v == "" {
		return def
	}
	n, err := strconv.ParseInt(v, 10, 64)
	if err != nil || n < 0 {
		return def
	}
	return n
}

func envFloat64(name string, def float64) float64 {
	v := os.Getenv(name)
	if v == "" {
		return def
	}
	n, err := strconv.ParseFloat(v, 64)
	if err != nil || n <= 0 {
		return def
	}
	return n
}

func envBool(name string, def bool) bool {
	v := os.Getenv(name)
	if v == "" {
		return def
	}
	switch v {
	case "1", "true", "TRUE", "yes", "YES", "on", "ON":
		return true
	case "0", "false", "FALSE", "no", "NO", "off", "OFF":
		return false
	default:
		return def
	}
}

func boolInt(v bool) int {
	if v {
		return 1
	}
	return 0
}

func bucketTTLSeconds(capacity, refillPerSecond float64) int {
	if capacity <= 0 || refillPerSecond <= 0 {
		return minBucketTTL
	}
	ttl := int(math.Ceil((capacity / refillPerSecond) * 2))
	if ttl < minBucketTTL {
		return minBucketTTL
	}
	return ttl
}
