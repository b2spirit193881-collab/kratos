package proxy

import (
	"encoding/json"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"

	"costguard/internal/cache"
	"costguard/internal/limiter"
	"costguard/internal/metrics"
)

// hopByHopHeaders must not be forwarded per RFC 7230.
var hopByHopHeaders = map[string]bool{
	"connection":          true,
	"keep-alive":          true,
	"proxy-authenticate":  true,
	"proxy-authorization": true,
	"te":                  true,
	"trailers":            true,
	"transfer-encoding":   true,
	"upgrade":             true,
}

type errorResponse struct {
	Error string `json:"error"`
}

type rateLimitResponse struct {
	Error             string `json:"error"`
	TenantID          string `json:"tenant_id"`
	Reason            string `json:"reason"`
	RetryAfterSeconds int    `json:"retry_after_seconds"`
}

type healthResponse struct {
	Status string `json:"status"`
}

// Handler implements the CostGuard reverse proxy entrypoint.
type Handler struct {
	client             *http.Client
	limiter            *limiter.Limiter
	cache              *cache.Service
	metrics            *metrics.Recorder
	defaultCost        float64
	metricsOn          bool
	allowedTargetHosts map[string]bool
}

// NewHandler builds a proxy handler with optional limiter, cache, and metrics.
func NewHandler(l *limiter.Limiter, c *cache.Service, rec *metrics.Recorder, defaultCost float64, metricsEnabled bool, allowedHosts []string) *Handler {
	return &Handler{
		client: &http.Client{
			Transport: &http.Transport{
				Proxy:                 http.ProxyFromEnvironment,
				ResponseHeaderTimeout: 60 * time.Second,
				IdleConnTimeout:       90 * time.Second,
			},
			CheckRedirect: func(req *http.Request, via []*http.Request) error {
				return http.ErrUseLastResponse
			},
		},
		limiter:            l,
		cache:              c,
		metrics:            rec,
		defaultCost:        defaultCost,
		metricsOn:          metricsEnabled,
		allowedTargetHosts: allowedHostSet(allowedHosts),
	}
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	start := time.Now()
	requestID := uuid.NewString()
	w.Header().Set(RequestIDHeader, requestID)

	if isHealthRequest(r) {
		writeJSON(w, http.StatusOK, healthResponse{Status: "ok"})
		return
	}

	tenantID := strings.TrimSpace(r.Header.Get(TenantIDHeader))
	targetRaw := strings.TrimSpace(r.Header.Get(TargetURLHeader))
	cacheStatus := "none"
	statusCode := http.StatusOK
	var bodyBuf []byte
	var tokenUsage *metrics.TokenUsage
	var targetURL *url.URL

	defer func() {
		h.recordMetric(start, requestID, tenantID, targetURL, cacheStatus, statusCode, r, bodyBuf, tokenUsage)
	}()

	if targetRaw == "" {
		statusCode = http.StatusBadRequest
		writeJSON(w, statusCode, errorResponse{
			Error: "missing required header: " + TargetURLHeader,
		})
		return
	}

	if tenantID == "" {
		statusCode = http.StatusBadRequest
		writeJSON(w, statusCode, errorResponse{
			Error: "missing required header: " + TenantIDHeader,
		})
		return
	}

	var err error
	targetURL, err = url.ParseRequestURI(targetRaw)
	if err != nil || targetURL.Scheme == "" || targetURL.Host == "" {
		statusCode = http.StatusBadRequest
		writeJSON(w, statusCode, errorResponse{
			Error: "invalid " + TargetURLHeader + ": must be an absolute http or https URL",
		})
		return
	}
	if targetURL.Scheme != "http" && targetURL.Scheme != "https" {
		statusCode = http.StatusBadRequest
		writeJSON(w, statusCode, errorResponse{
			Error: "invalid " + TargetURLHeader + ": scheme must be http or https",
		})
		return
	}
	if !h.isAllowedTarget(targetURL) {
		statusCode = http.StatusForbidden
		writeJSON(w, statusCode, errorResponse{
			Error: "target host is not allowed",
		})
		return
	}

	if h.limiter != nil {
		if res := h.limiter.AllowRequest(r.Context(), tenantID); !res.Allowed {
			statusCode = http.StatusTooManyRequests
			writeRateLimit(w, tenantID, res)
			return
		}
	}

	cacheHdr := r.Header.Get(cache.HeaderCacheControl)
	mode := cache.ResolveMode(r.Method, cacheHdr)
	if mode == cache.ModeBypass {
		cacheStatus = CacheBypassValue
	}

	bodyReader := r.Body
	if h.cache != nil && h.cache.Enabled() && mode == cache.ModeActive {
		bodyBuf, bodyReader, err = cache.ReadBodyIfNeeded(r, mode)
		if err != nil {
			statusCode = http.StatusBadRequest
			writeJSON(w, statusCode, errorResponse{Error: "failed to read request body"})
			return
		}
	}

	var cacheKey string
	var ttl time.Duration
	if h.cache != nil && h.cache.Enabled() && mode == cache.ModeActive {
		ttl, err = h.cache.ParseTTL(r.Header.Get(cache.HeaderTTL))
		if err != nil {
			statusCode = http.StatusBadRequest
			writeJSON(w, statusCode, errorResponse{
				Error: "invalid " + cache.HeaderTTL + ": must be integer seconds between 1 and 86400",
			})
			return
		}
		fp := cache.Fingerprint(tenantID, targetRaw, r.Method, r.Header, bodyBuf)
		cacheKey = cache.RedisKey(tenantID, fp)

		if entry, _ := h.cache.Get(r.Context(), cacheKey); entry != nil {
			cacheStatus = CacheHitValue
			tokenUsage = metrics.ExtractOpenAIChatUsage(targetURL, entry.StatusCode, entry.Body)
			cache.WriteHit(w, entry)
			statusCode = entry.StatusCode
			return
		}
		cacheStatus = CacheMissValue
	}

	if cacheStatus != CacheHitValue && h.limiter != nil {
		if res := h.limiter.ConsumeBudget(r.Context(), tenantID); !res.Allowed {
			statusCode = http.StatusTooManyRequests
			writeRateLimit(w, tenantID, res)
			return
		}
	}

	respCacheHdr := ""
	switch cacheStatus {
	case CacheMissValue:
		respCacheHdr = cache.StatusMiss
	case CacheBypassValue:
		respCacheHdr = cache.StatusBypass
	}
	upstream := h.forwardUpstream(w, r, targetURL, bodyReader, cacheKey, ttl, respCacheHdr)
	statusCode = upstream.StatusCode
	tokenUsage = upstream.TokenUsage
}

func (h *Handler) recordMetric(
	start time.Time,
	requestID, tenantID string,
	targetURL *url.URL,
	cacheStatus string,
	statusCode int,
	r *http.Request,
	body []byte,
	tokenUsage *metrics.TokenUsage,
) {
	if !h.metricsOn || h.metrics == nil {
		return
	}
	ev := metrics.Event{
		ExecutionTimeMS: time.Since(start).Milliseconds(),
		StatusCode:      statusCode,
		TenantID:        tenantID,
		TargetURL:       metrics.SanitizeTargetURL(targetURL),
		CacheStatus:     cacheStatus,
		EstimatedCost:   metrics.EstimateCost(h.defaultCost, r, body),
		Timestamp:       time.Now().UTC().Format(time.RFC3339),
		RequestID:       requestID,
	}
	if tokenUsage != nil {
		ev.Vendor = tokenUsage.Vendor
		ev.PromptTokens = tokenUsage.PromptTokens
		ev.CompletionTokens = tokenUsage.CompletionTokens
		ev.TotalTokens = tokenUsage.TotalTokens
	}
	h.metrics.Record(ev)
}

type upstreamResult struct {
	StatusCode  int
	TokenUsage *metrics.TokenUsage
}

func (h *Handler) forwardUpstream(
	w http.ResponseWriter,
	r *http.Request,
	targetURL *url.URL,
	body io.ReadCloser,
	cacheKey string,
	ttl time.Duration,
	responseCacheHeader string,
) upstreamResult {
	if body == nil {
		body = http.NoBody
	}
	defer body.Close()

	outReq, err := http.NewRequestWithContext(r.Context(), r.Method, targetURL.String(), body)
	if err != nil {
		writeJSON(w, http.StatusBadRequest, errorResponse{Error: "failed to build upstream request"})
		return upstreamResult{StatusCode: http.StatusBadRequest}
	}
	copyForwardHeaders(r.Header, outReq.Header)

	resp, err := h.client.Do(outReq)
	if err != nil {
		writeJSON(w, http.StatusBadGateway, errorResponse{
			Error: "upstream request failed: " + err.Error(),
		})
		return upstreamResult{StatusCode: http.StatusBadGateway}
	}
	defer resp.Body.Close()

	if responseCacheHeader != "" {
		w.Header().Set(cache.HeaderCacheControl, responseCacheHeader)
	}
	copyResponseHeaders(w, resp)
	w.WriteHeader(resp.StatusCode)

	shouldInspectUsage := metrics.ShouldParseOpenAIChatUsage(targetURL, resp.StatusCode, resp.Header.Get("Content-Type"))
	if (cacheKey != "" && h.cache != nil) || shouldInspectUsage {
		respBody, err := io.ReadAll(resp.Body)
		if err != nil {
			return upstreamResult{StatusCode: resp.StatusCode}
		}
		_, _ = w.Write(respBody)
		if cacheKey != "" && h.cache != nil && cache.ShouldStore(resp.StatusCode) {
			h.cache.Set(r.Context(), cacheKey, &cache.Entry{
				StatusCode: resp.StatusCode,
				Headers:    cache.HeadersForStorage(resp.Header),
				Body:       respBody,
			}, ttl)
		}
		return upstreamResult{
			StatusCode:  resp.StatusCode,
			TokenUsage: metrics.ExtractOpenAIChatUsage(targetURL, resp.StatusCode, respBody),
		}
	}

	_, _ = io.Copy(w, resp.Body)
	return upstreamResult{StatusCode: resp.StatusCode}
}

func allowedHostSet(hosts []string) map[string]bool {
	out := make(map[string]bool, len(hosts))
	for _, host := range hosts {
		normalized := strings.ToLower(strings.TrimSpace(host))
		if normalized != "" {
			out[normalized] = true
		}
	}
	return out
}

func (h *Handler) isAllowedTarget(u *url.URL) bool {
	if u == nil || len(h.allowedTargetHosts) == 0 {
		return false
	}
	return h.allowedTargetHosts[strings.ToLower(u.Hostname())]
}

func isHealthRequest(r *http.Request) bool {
	if r.Method != http.MethodGet {
		return false
	}
	switch r.URL.Path {
	case "/health", "/_costguard/health":
		return true
	default:
		return false
	}
}

func writeRateLimit(w http.ResponseWriter, tenantID string, res limiter.Result) {
	w.Header().Set("Content-Type", "application/json")
	if res.RetryAfterSeconds > 0 {
		w.Header().Set("Retry-After", strconv.Itoa(res.RetryAfterSeconds))
	}
	w.WriteHeader(http.StatusTooManyRequests)
	_ = json.NewEncoder(w).Encode(rateLimitResponse{
		Error:             "rate_limit_exceeded",
		TenantID:          tenantID,
		Reason:            res.Reason,
		RetryAfterSeconds: res.RetryAfterSeconds,
	})
}

func copyForwardHeaders(src http.Header, dst http.Header) {
	connectionTokens := connectionHeaderTokens(src)

	for name, values := range src {
		key := strings.ToLower(name)
		if isInternalHeader(key) {
			continue
		}
		if hopByHopHeaders[key] || connectionTokens[key] {
			continue
		}
		for _, v := range values {
			dst.Add(name, v)
		}
	}
}

func isInternalHeader(key string) bool {
	switch key {
	case strings.ToLower(TargetURLHeader),
		strings.ToLower(TenantIDHeader),
		strings.ToLower(RequestIDHeader),
		strings.ToLower(cache.HeaderCacheControl),
		strings.ToLower(cache.HeaderTTL):
		return true
	default:
		return false
	}
}

func connectionHeaderTokens(h http.Header) map[string]bool {
	tokens := make(map[string]bool)
	for _, v := range h["Connection"] {
		for _, part := range strings.Split(v, ",") {
			t := strings.ToLower(strings.TrimSpace(part))
			if t != "" {
				tokens[t] = true
			}
		}
	}
	return tokens
}

func copyResponseHeaders(w http.ResponseWriter, resp *http.Response) {
	dst := w.Header()
	for name, values := range resp.Header {
		key := strings.ToLower(name)
		if hopByHopHeaders[key] {
			continue
		}
		for _, v := range values {
			dst.Add(name, v)
		}
	}
}

func writeJSON(w http.ResponseWriter, status int, body any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(body)
}
