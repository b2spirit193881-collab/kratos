package proxy

const (
	TargetURLHeader  = "X-CostGuard-Target-URL"
	TenantIDHeader   = "X-CostGuard-Tenant-ID"
	RequestIDHeader  = "X-CostGuard-Request-ID"
	CacheHeader      = "X-CostGuard-Cache"
	TTLHeader        = "X-CostGuard-TTL"
	CacheEnableValue = "ENABLE"
	CacheBypassValue = "BYPASS"
	CacheHitValue    = "HIT"
	CacheMissValue   = "MISS"
)
