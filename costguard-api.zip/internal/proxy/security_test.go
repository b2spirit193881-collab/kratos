package proxy

import (
	"net/http"
	"net/http/httptest"
	"net/url"
	"testing"
)

func TestRejectsDisallowedTargetHost(t *testing.T) {
	h := NewHandler(nil, nil, nil, 0, false, []string{"api.openai.com"})
	req := httptest.NewRequest(http.MethodGet, "/", nil)
	req.Header.Set(TenantIDHeader, "tenant-a")
	req.Header.Set(TargetURLHeader, "https://example.com/v1/chat/completions")
	rr := httptest.NewRecorder()

	h.ServeHTTP(rr, req)

	if rr.Code != http.StatusForbidden {
		t.Fatalf("expected 403, got %d", rr.Code)
	}
}

func TestAllowedTargetHostExactMatch(t *testing.T) {
	h := NewHandler(nil, nil, nil, 0, false, []string{"api.openai.com"})
	allowed, _ := url.Parse("https://api.openai.com:443/v1/chat/completions")
	disallowed, _ := url.Parse("https://evil.api.openai.com/v1/chat/completions")

	if !h.isAllowedTarget(allowed) {
		t.Fatal("expected api.openai.com to be allowed")
	}
	if h.isAllowedTarget(disallowed) {
		t.Fatal("expected subdomain of allowed host to be rejected")
	}
}
