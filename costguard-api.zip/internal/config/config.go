package config

import (
	"os"
	"strconv"
	"strings"
)

// Config holds CostGuard proxy runtime settings.
type Config struct {
	ListenAddr string

	AllowedTargetHosts []string

	RedisAddr     string
	RedisPassword string

	RequestRefillRatePerSecond float64
	RequestBurstCapacity       float64
	SpikeBreakerEnabled       bool
	SpikeMinRequestsPerMinute int64
	SpikeMultiplier           float64
	SpikeBlockSeconds         int64
	DefaultHourlyBudget        int64
	DefaultRequestCost         int64

	CacheDefaultTTLSeconds int
	CacheMaxTTLSeconds     int

	MetricsEnabled     bool
	MetricsDBPath      string
	MetricsDefaultCost float64
	MetricsWorkers     int
	MetricsBuffer      int

	LogLevel string
}

// Load reads configuration from environment variables.
func Load() Config {
	return Config{
		ListenAddr: envOr("LISTEN_ADDR", ":8080"),
		AllowedTargetHosts: envCSV("ALLOWED_TARGET_HOSTS", []string{
			"api.openai.com",
			"api.anthropic.com",
			"api.google.com",
		}),
		// Empty/unset REDIS_ADDR → localhost:6379 for local dev; Docker Compose sets REDIS_ADDR (e.g. redis:6379).
		RedisAddr: envOr("REDIS_ADDR", "localhost:6379"),
		RedisPassword:             os.Getenv("REDIS_PASSWORD"),
		RequestRefillRatePerSecond: envFloat64("REQUEST_REFILL_RATE_PER_SECOND", 10),
		RequestBurstCapacity:       envFloat64("REQUEST_BURST_CAPACITY", 100),
		SpikeBreakerEnabled:       envBool("SPIKE_BREAKER_ENABLED", true),
		SpikeMinRequestsPerMinute: envInt64("SPIKE_MIN_REQUESTS_PER_MINUTE", 100),
		SpikeMultiplier:           envFloat64("SPIKE_MULTIPLIER", 5),
		SpikeBlockSeconds:         envInt64("SPIKE_BLOCK_SECONDS", 900),
		DefaultHourlyBudget:        envInt64("DEFAULT_HOURLY_BUDGET_LIMIT", 10000),
		DefaultRequestCost:         envInt64("DEFAULT_REQUEST_COST", 1),
		CacheDefaultTTLSeconds:     int(envInt64("CACHE_DEFAULT_TTL_SECONDS", 300)),
		CacheMaxTTLSeconds:         int(envInt64("CACHE_MAX_TTL_SECONDS", 86400)),
		MetricsEnabled:             envBool("METRICS_ENABLED", true),
		MetricsDBPath:              os.Getenv("METRICS_DB_PATH"),
		MetricsDefaultCost:         envFloat64("METRICS_DEFAULT_COST_USD", 0.001),
		MetricsWorkers:             int(envInt64("METRICS_WORKERS", 4)),
		MetricsBuffer:              int(envInt64("METRICS_CHANNEL_BUFFER", 1024)),
		LogLevel:                   strings.ToLower(envOr("LOG_LEVEL", "info")),
	}
}

func envOr(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func envInt64(key string, fallback int64) int64 {
	raw := os.Getenv(key)
	if raw == "" {
		return fallback
	}
	n, err := strconv.ParseInt(raw, 10, 64)
	if err != nil || n < 0 {
		return fallback
	}
	return n
}

func envFloat64(key string, fallback float64) float64 {
	raw := os.Getenv(key)
	if raw == "" {
		return fallback
	}
	n, err := strconv.ParseFloat(raw, 64)
	if err != nil || n < 0 {
		return fallback
	}
	return n
}

func envBool(key string, fallback bool) bool {
	raw := strings.TrimSpace(os.Getenv(key))
	if raw == "" {
		return fallback
	}
	switch strings.ToLower(raw) {
	case "1", "true", "yes", "on":
		return true
	case "0", "false", "no", "off":
		return false
	default:
		return fallback
	}
}

func envCSV(key string, fallback []string) []string {
	raw := os.Getenv(key)
	if strings.TrimSpace(raw) == "" {
		return fallback
	}
	var out []string
	for _, part := range strings.Split(raw, ",") {
		v := strings.ToLower(strings.TrimSpace(part))
		if v != "" {
			out = append(out, v)
		}
	}
	if len(out) == 0 {
		return fallback
	}
	return out
}
