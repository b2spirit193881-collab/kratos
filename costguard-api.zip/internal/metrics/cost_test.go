package metrics

import (
	"net/http"
	"net/url"
	"testing"
)

func TestExtractOpenAIChatUsage(t *testing.T) {
	target, _ := url.Parse("https://api.openai.com/v1/chat/completions")
	body := []byte(`{"id":"chatcmpl_1","usage":{"prompt_tokens":12,"completion_tokens":34,"total_tokens":46}}`)

	usage := ExtractOpenAIChatUsage(target, http.StatusOK, body)
	if usage == nil {
		t.Fatal("expected usage")
	}
	if usage.Vendor != "openai" || usage.PromptTokens != 12 || usage.CompletionTokens != 34 || usage.TotalTokens != 46 {
		t.Fatalf("unexpected usage: %+v", usage)
	}
}

func TestExtractOpenAIChatUsageFailOpen(t *testing.T) {
	target, _ := url.Parse("https://api.openai.com/v1/chat/completions")

	if usage := ExtractOpenAIChatUsage(target, http.StatusOK, []byte(`not-json`)); usage != nil {
		t.Fatalf("expected invalid JSON to return nil, got %+v", usage)
	}
	if usage := ExtractOpenAIChatUsage(target, http.StatusBadRequest, []byte(`{"usage":{"prompt_tokens":1}}`)); usage != nil {
		t.Fatalf("expected non-2xx response to return nil, got %+v", usage)
	}
}

func TestShouldParseOpenAIChatUsageOnlyForExactEndpoint(t *testing.T) {
	target, _ := url.Parse("https://api.openai.com/v1/chat/completions")
	otherPath, _ := url.Parse("https://api.openai.com/v1/responses")
	otherHost, _ := url.Parse("https://example.com/v1/chat/completions")

	if !ShouldParseOpenAIChatUsage(target, http.StatusOK, "application/json") {
		t.Fatal("expected OpenAI chat completions endpoint to be eligible")
	}
	if ShouldParseOpenAIChatUsage(otherPath, http.StatusOK, "application/json") {
		t.Fatal("expected other OpenAI endpoint to be ignored")
	}
	if ShouldParseOpenAIChatUsage(otherHost, http.StatusOK, "application/json") {
		t.Fatal("expected other host to be ignored")
	}
	if ShouldParseOpenAIChatUsage(target, http.StatusOK, "text/event-stream") {
		t.Fatal("expected streaming responses to be ignored")
	}
}
