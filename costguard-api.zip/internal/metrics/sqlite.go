package metrics

import (
	"database/sql"
	"fmt"

	_ "modernc.org/sqlite"
)

type sqliteStore struct {
	db *sql.DB
}

func openSQLite(path string) (*sqliteStore, error) {
	db, err := sql.Open("sqlite", path)
	if err != nil {
		return nil, err
	}
	if _, err := db.Exec(`
CREATE TABLE IF NOT EXISTS request_metrics (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  execution_time_ms INTEGER NOT NULL,
  status_code INTEGER NOT NULL,
  tenant_id TEXT NOT NULL,
  target_url TEXT NOT NULL,
  cache_status TEXT NOT NULL,
  estimated_cost REAL NOT NULL,
  vendor TEXT NOT NULL DEFAULT '',
  prompt_tokens INTEGER NOT NULL DEFAULT 0,
  completion_tokens INTEGER NOT NULL DEFAULT 0,
  total_tokens INTEGER NOT NULL DEFAULT 0,
  timestamp TEXT NOT NULL,
  request_id TEXT NOT NULL UNIQUE
);
CREATE INDEX IF NOT EXISTS idx_request_metrics_ts ON request_metrics(timestamp);
CREATE INDEX IF NOT EXISTS idx_request_metrics_tenant ON request_metrics(tenant_id);
`); err != nil {
		_ = db.Close()
		return nil, fmt.Errorf("init schema: %w", err)
	}
	if err := ensureMetricColumns(db); err != nil {
		_ = db.Close()
		return nil, fmt.Errorf("migrate schema: %w", err)
	}
	return &sqliteStore{db: db}, nil
}

func (s *sqliteStore) insert(ev Event) error {
	_, err := s.db.Exec(`
INSERT INTO request_metrics (
  execution_time_ms, status_code, tenant_id, target_url,
  cache_status, estimated_cost, vendor, prompt_tokens, completion_tokens,
  total_tokens, timestamp, request_id
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		ev.ExecutionTimeMS, ev.StatusCode, ev.TenantID, ev.TargetURL,
		ev.CacheStatus, ev.EstimatedCost, ev.Vendor, ev.PromptTokens,
		ev.CompletionTokens, ev.TotalTokens, ev.Timestamp, ev.RequestID,
	)
	return err
}

func ensureMetricColumns(db *sql.DB) error {
	rows, err := db.Query(`PRAGMA table_info(request_metrics)`)
	if err != nil {
		return err
	}
	defer rows.Close()

	seen := map[string]bool{}
	for rows.Next() {
		var cid int
		var name, typ string
		var notNull int
		var defaultValue any
		var pk int
		if err := rows.Scan(&cid, &name, &typ, &notNull, &defaultValue, &pk); err != nil {
			return err
		}
		seen[name] = true
	}
	if err := rows.Err(); err != nil {
		return err
	}

	columns := map[string]string{
		"vendor":            "TEXT NOT NULL DEFAULT ''",
		"prompt_tokens":     "INTEGER NOT NULL DEFAULT 0",
		"completion_tokens": "INTEGER NOT NULL DEFAULT 0",
		"total_tokens":      "INTEGER NOT NULL DEFAULT 0",
	}
	for name, definition := range columns {
		if seen[name] {
			continue
		}
		if _, err := db.Exec("ALTER TABLE request_metrics ADD COLUMN " + name + " " + definition); err != nil {
			return err
		}
	}
	return nil
}

func (s *sqliteStore) close() error {
	if s == nil || s.db == nil {
		return nil
	}
	return s.db.Close()
}
