package metrics

import (
	"encoding/json"
	"log"
	"net/url"
	"os"
	"sync"
	"time"
)

// Event is one completed proxied request metric record.
type Event struct {
	ExecutionTimeMS int64   `json:"execution_time_ms"`
	StatusCode      int     `json:"status_code"`
	TenantID        string  `json:"tenant_id"`
	TargetURL       string  `json:"target_url"`
	CacheStatus     string  `json:"cache_status"`
	EstimatedCost   float64 `json:"estimated_cost"`
	Vendor          string  `json:"vendor,omitempty"`
	PromptTokens    int     `json:"prompt_tokens,omitempty"`
	CompletionTokens int    `json:"completion_tokens,omitempty"`
	TotalTokens     int     `json:"total_tokens,omitempty"`
	Timestamp       string  `json:"timestamp"`
	RequestID       string  `json:"request_id"`
}

// Recorder asynchronously logs request metrics (stdout JSON + optional SQLite).
type Recorder struct {
	enabled bool
	ch      chan Event
	wg      sync.WaitGroup
	db      *sqliteStore
}

// NewRecorder starts a buffered worker pool. dbPath empty skips SQLite.
func NewRecorder(enabled bool, workers, buffer int, dbPath string) *Recorder {
	if !enabled {
		return &Recorder{enabled: false}
	}
	if workers < 1 {
		workers = 1
	}
	if buffer < 1 {
		buffer = 256
	}

	r := &Recorder{
		enabled: true,
		ch:      make(chan Event, buffer),
	}

	if dbPath != "" {
		db, err := openSQLite(dbPath)
		if err != nil {
			log.Printf("metrics: sqlite disabled: %v", err)
		} else {
			r.db = db
		}
	}

	for i := 0; i < workers; i++ {
		r.wg.Add(1)
		go r.worker()
	}
	return r
}

func (r *Recorder) worker() {
	defer r.wg.Done()
	for ev := range r.ch {
		r.writeStdout(ev)
		if r.db != nil {
			if err := r.db.insert(ev); err != nil {
				log.Printf("metrics: sqlite write failed: %v", err)
			}
		}
	}
}

func (r *Recorder) writeStdout(ev Event) {
	line, err := json.Marshal(ev)
	if err != nil {
		log.Printf("metrics: encode failed: %v", err)
		return
	}
	_, _ = os.Stdout.Write(append(line, '\n'))
}

// Record enqueues a metric without blocking the hot path (drops if buffer full).
func (r *Recorder) Record(ev Event) {
	if r == nil || !r.enabled {
		return
	}
	if ev.Timestamp == "" {
		ev.Timestamp = time.Now().UTC().Format(time.RFC3339)
	}
	select {
	case r.ch <- ev:
	default:
		log.Printf("metrics: dropped event (buffer full) request_id=%s", ev.RequestID)
	}
}

// Close drains workers and closes SQLite.
func (r *Recorder) Close() {
	if r == nil || !r.enabled {
		return
	}
	close(r.ch)
	r.wg.Wait()
	if r.db != nil {
		_ = r.db.close()
	}
}

// SanitizeTargetURL returns host + path only (no query secrets).
func SanitizeTargetURL(u *url.URL) string {
	if u == nil {
		return ""
	}
	path := u.EscapedPath()
	if path == "" {
		path = "/"
	}
	return u.Host + path
}
