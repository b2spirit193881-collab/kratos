package metrics

import (
	"encoding/json"
	"net/http"
	"net/url"
	"strconv"
	"strings"
)

// TokenUsage captures vendor-reported token usage from a successful response.
type TokenUsage struct {
	Vendor           string
	PromptTokens     int
	CompletionTokens int
	TotalTokens      int
}

// EstimateCost returns a simple financial estimate for a proxied request.
//
// Heuristic (documented in README):
//  1. Start from METRICS_DEFAULT_COST_USD (or config default).
//  2. If Content-Length is set on the request, add $0.000001 per KiB (rough payload weight).
//  3. For POST JSON bodies, if max_tokens is present, add $0.00001 per token (rough LLM proxy).
func EstimateCost(defaultCost float64, r *http.Request, body []byte) float64 {
	cost := defaultCost

	if cl := r.Header.Get("Content-Length"); cl != "" {
		if n, err := strconv.ParseInt(cl, 10, 64); err == nil && n > 0 {
			cost += float64(n) / (1024.0 * 1_000_000.0)
		}
	} else if len(body) > 0 {
		cost += float64(len(body)) / (1024.0 * 1_000_000.0)
	}

	if len(body) > 0 && strings.Contains(r.Header.Get("Content-Type"), "json") {
		var partial struct {
			MaxTokens *int `json:"max_tokens"`
		}
		if err := json.Unmarshal(body, &partial); err == nil && partial.MaxTokens != nil && *partial.MaxTokens > 0 {
			cost += float64(*partial.MaxTokens) * 0.00001
		}
	}

	return cost
}

// ShouldParseOpenAIChatUsage reports whether a response is eligible for OpenAI
// chat-completion usage extraction.
func ShouldParseOpenAIChatUsage(targetURL *url.URL, statusCode int, contentType string) bool {
	return statusCode >= 200 &&
		statusCode < 300 &&
		targetURL != nil &&
		strings.EqualFold(targetURL.Hostname(), "api.openai.com") &&
		strings.TrimRight(targetURL.EscapedPath(), "/") == "/v1/chat/completions" &&
		strings.Contains(strings.ToLower(contentType), "json")
}

// ExtractOpenAIChatUsage best-effort parses usage from OpenAI chat completion
// responses. Invalid JSON or missing fields returns nil so telemetry remains
// fail-open and never changes proxy behavior.
func ExtractOpenAIChatUsage(targetURL *url.URL, statusCode int, body []byte) *TokenUsage {
	if !isOpenAIChatCompletion(targetURL, statusCode) || len(body) == 0 {
		return nil
	}
	var payload struct {
		Usage struct {
			PromptTokens     int `json:"prompt_tokens"`
			CompletionTokens int `json:"completion_tokens"`
			TotalTokens      int `json:"total_tokens"`
		} `json:"usage"`
	}
	if err := json.Unmarshal(body, &payload); err != nil {
		return nil
	}
	if payload.Usage.PromptTokens == 0 && payload.Usage.CompletionTokens == 0 && payload.Usage.TotalTokens == 0 {
		return nil
	}
	total := payload.Usage.TotalTokens
	if total == 0 {
		total = payload.Usage.PromptTokens + payload.Usage.CompletionTokens
	}
	return &TokenUsage{
		Vendor:           "openai",
		PromptTokens:     payload.Usage.PromptTokens,
		CompletionTokens: payload.Usage.CompletionTokens,
		TotalTokens:      total,
	}
}

func isOpenAIChatCompletion(targetURL *url.URL, statusCode int) bool {
	return statusCode >= 200 &&
		statusCode < 300 &&
		targetURL != nil &&
		strings.EqualFold(targetURL.Hostname(), "api.openai.com") &&
		strings.TrimRight(targetURL.EscapedPath(), "/") == "/v1/chat/completions"
}
